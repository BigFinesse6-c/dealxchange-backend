# app/db/seed.py
import asyncio
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy.future import select
from app.db.database import engine, Base
from app.models.user import User, UserRole
from app.models.listing import Listing
from app.utils.security import hash_password

async def seed():
    # 1️⃣ Create all tables (fresh)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # 2️⃣ Async session
    async_session_local = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    async with async_session_local() as session:
        # --- Users ---
        users_to_seed = [
            ("admin@dealxchange.com", "admin123", UserRole.admin, True),
            ("seller@dealxchange.com", "seller123", UserRole.seller, True),
            ("buyer@dealxchange.com", "buyer123", UserRole.buyer, False),
            ("wholesaler@dealxchange.com", "wholesaler123", UserRole.wholesaler, True),
        ]

        for email, password, role, approved in users_to_seed:
            result = await session.execute(select(User).where(User.email == email))
            user = result.scalars().first()
            if not user:
                user = User(
                    email=email,
                    hashed_password=hash_password(password),
                    role=role,
                    approved=approved
                )
                session.add(user)

        await session.commit()

        # --- Listings for Seller ---
        result = await session.execute(select(User).where(User.email == "seller@dealxchange.com"))
        seller = result.scalars().first()
        if seller:
            result = await session.execute(select(Listing).where(Listing.owner_id == seller.id))
            if not result.scalars().first():
                seller_listings = [
                    Listing(
                        title="3-Bed Starter Home",
                        address="2501 S Cherry St",
                        zip_code="71601",
                        year_built=1995,
                        square_footage=1450,
                        price=85000,
                        description="Perfect first home with updated kitchen and fenced yard.",
                        image_url="/assets/images/home1.jpg",
                        arv=120000,
                        owner_id=seller.id,
                        approved=True  # pre-approved
                    ),
                    Listing(
                        title="Fix & Flip Opportunity",
                        address="4320 Maple Ave",
                        zip_code="72204",
                        year_built=1978,
                        square_footage=1100,
                        price=40000,
                        description="Needs full rehab but comps in area are $150k+. Great ARV potential.",
                        image_url="/assets/images/home2.jpg",
                        arv=150000,
                        owner_id=seller.id,
                        approved=False
                    ),
                    Listing(
                        title="Duplex Investment Property",
                        address="1812 College Ave",
                        zip_code="72032",
                        year_built=1988,
                        square_footage=2200,
                        price=120000,
                        description="Cash-flowing duplex with long-term tenants in place.",
                        image_url="/assets/images/duplex.jpg",
                        arv=160000,
                        owner_id=seller.id,
                        approved=True
                    ),
                ]
                session.add_all(seller_listings)
                await session.commit()

        # --- Listings for Wholesaler ---
        result = await session.execute(select(User).where(User.email == "wholesaler@dealxchange.com"))
        wholesaler = result.scalars().first()
        if wholesaler:
            result = await session.execute(select(Listing).where(Listing.owner_id == wholesaler.id))
            if not result.scalars().first():
                wholesaler_listings = [
                    Listing(
                        title="Wholesale Deal - Single Family",
                        address="210 Pine St",
                        zip_code="71603",
                        year_built=1965,
                        square_footage=1300,
                        price=60000,
                        description="Assignment contract, $10k spread potential.",
                        image_url="/assets/images/home2.jpeg",
                        arv=95000,
                        owner_id=wholesaler.id,
                        approved=True
                    ),
                    Listing(
                        title="Discounted 4-Plex",
                        address="980 Oak St",
                        zip_code="72205",
                        year_built=1972,
                        square_footage=3200,
                        price=95000,
                        description="Wholesale 4-plex, tenants month-to-month. Great rental potential.",
                        image_url="/assets/images/home1.jpeg",
                        arv=180000,
                        owner_id=wholesaler.id,
                        approved=False
                    ),
                ]
                session.add_all(wholesaler_listings)
                await session.commit()

if __name__ == "__main__":
    asyncio.run(seed())
