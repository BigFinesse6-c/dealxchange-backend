from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.db.database import init_models  # async table creation
from app.api.v1.api import api_router

# Initialize app
app = FastAPI(title=getattr(settings, "PROJECT_NAME", "FastAPI App"))

# Startup event - initialize database tables
@app.on_event("startup")
async def startup():
    await init_models()

# Register routers
app.include_router(api_router, prefix="/api/v1")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],       # You can restrict this later
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Root endpoint
@app.get("/")
async def root():
    return {"message": f"{getattr(settings, 'PROJECT_NAME', 'FastAPI App')} API ready"}

