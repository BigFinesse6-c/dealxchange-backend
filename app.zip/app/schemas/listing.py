# app/schemas/listing.py
from pydantic import BaseModel

class ListingCreate(BaseModel):
    address: str
    zipcode: str
    yearBuilt: str
    squareFootage: str
    description: str
    price: int
    image_url: str | None = None
    arv: int
    approved:bool = False
    lat: float | None
    lng: float | None

class ListingRead(ListingCreate):
    id: int
    owner_id: int

    class Config:
        orm_mode = True


