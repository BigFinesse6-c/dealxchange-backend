# app/schemas/user.py
from pydantic import BaseModel
from typing import Optional
from app.models.user import UserRole
from enum import Enum

class UserRole(str, Enum):
    buyer = "buyer"
    seller = "seller"
    wholesaler = "wholesaler"
    admin = "admin"

class UserRead(BaseModel):
    id: int
    email: str
    full_name: Optional[str]
    role: UserRole  # ✅ Must include role
    is_active: bool
    is_verified_email: bool
    is_admin: bool = False
    approved: bool = False

    class Config:
        orm_mode = True

class UserCreate(BaseModel):
    email: str
    password: str
    full_name: Optional[str]
    role: Optional[UserRole] = UserRole.buyer

class UserLogin(BaseModel):
    email: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

