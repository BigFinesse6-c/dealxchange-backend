from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "DealXchange"
    DATABASE_URL: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    SECRET_KEY: str = "supersecretkey123"  # <-- add this

    class Config:
        env_file = ".env"

settings = Settings()

# Debug: print loaded settings (without secrets)
print("Loaded settings:", {
    "DATABASE_URL": settings.DATABASE_URL,
    "ALGORITHM": settings.ALGORITHM,
    "ACCESS_TOKEN_EXPIRE_MINUTES": settings.ACCESS_TOKEN_EXPIRE_MINUTES,
})

