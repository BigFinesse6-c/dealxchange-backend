from fastapi import APIRouter
from app.api.v1 import auth, listings

api_router = APIRouter()
api_router.include_router(auth.router, prefix="/auth", tags=["auth"])
api_router.include_router(listings.router, prefix="", tags=["listings"])

#"http://localhost:8000/api/v1/buyer-feed"
