# app/api/v1/listings.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.db.database import get_db
from app.models.listing import Listing
from app.models.request import Request
from app.models.user import User
from app.schemas.listing import ListingCreate, ListingRead
from app.schemas.request import RequestCreate, RequestOut
from app.core.auth import get_current_user

router = APIRouter()


# ✅ Buyer feed (only approved listings)
@router.get("/buyer-feed")
async def get_buyer_feed(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Listing).where(Listing.approved == True))
    listings = result.scalars().all()
    return {
        "items": [
            dict(
                id=l.id,
                title=l.title,
                address=l.address,
                zipCode=l.zip_code,
                yearBuilt=l.year_built,
                squareFootage=l.square_footage,
                price=l.price,
                description=l.description,
                imageUrl=l.image_url,
                arv=l.arv,
            )
            for l in listings
        ],
        "total": len(listings),
        "page": 1,
        "per_page": len(listings),
    }


# ✅ Create listing (auto-marked as pending)
@router.post("/listings", response_model=ListingRead)
async def create_listing(
    listing_in: ListingCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    new_listing = Listing(**listing_in.dict(), owner_id=current_user.id, approved=False)
    db.add(new_listing)
    await db.commit()
    await db.refresh(new_listing)
    return dict(
        id=new_listing.id,
        title=new_listing.title,
        address=new_listing.address,
        zipCode=new_listing.zip_code,
        yearBuilt=new_listing.year_built,
        squareFootage=new_listing.square_footage,
        price=new_listing.price,
        description=new_listing.description,
        imageUrl=new_listing.image_url,
        arv=new_listing.arv,
    )


# ✅ Admin: Get pending listings
@router.get("/admin/listings")
async def get_pending_listings(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Not authorized")

    result = await db.execute(select(Listing).where(Listing.approved == False))
    listings = result.scalars().all()
    return [
        dict(
            id=l.id,
            title=l.title,
            address=l.address,
            zipCode=l.zip_code,
            yearBuilt=l.year_built,
            squareFootage=l.square_footage,
            price=l.price,
            description=l.description,
            imageUrl=l.image_url,
            arv=l.arv,
        )
        for l in listings
    ]


# ✅ Get all listings (sync replacement removed → now async)
@router.get("/listings")
async def get_listings(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Listing))
    return result.scalars().all()


# ✅ Create buyer request for a listing
@router.post("/listings/{listing_id}/request")
async def create_request(
    listing_id: int,
    req: RequestCreate,
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Listing).where(Listing.id == listing_id))
    listing = result.scalar_one_or_none()
    if not listing:
        raise HTTPException(status_code=404, detail="Listing not found")

    new_request = Request(**req.dict(), listing_id=listing_id)
    db.add(new_request)
    await db.commit()
    await db.refresh(new_request)
    return new_request
    
@router.post("/request-deal", response_model=RequestOut)
async def create_request(
    req: RequestCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    new_request = Request(
        listing_id=req.listing_id,
        user_id=current_user.id,
        message=req.message,
    )
    db.add(new_request)
    await db.commit()
    await db.refresh(new_request)
    return new_request


